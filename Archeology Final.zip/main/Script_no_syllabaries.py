import os
import numpy as np
import torch
from PIL import Image
from torchvision.models import resnet50, ResNet50_Weights
import matplotlib
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
import umap
import zipfile
import traceback
import shutil
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt


def extract_features(image_path, resnet, transform, device):
    image = Image.open(image_path).convert('RGB')
    image = transform(image).unsqueeze(0).to(device)
    with torch.no_grad():
        features = resnet(image)
    return features.squeeze().cpu().numpy()


def plot_with_syllabaries(title, X_main, labels_main, X_syll, labels_syll, clusters):
    plt.figure(figsize=(9, 6))
    X_main = np.array(X_main)
    clusters = np.array(clusters)
    plt.scatter(X_main[:, 0], X_main[:, 1],
                c=clusters, cmap='viridis', s=100, label='Clustered')

    for i, (x, y) in enumerate(X_main):
        plt.annotate(labels_main[i], (x, y), fontsize=8)
        plt.text(x, y, f"{clusters[i]}", fontsize=6, alpha=0.5)

    #Syllabaries
    if len(X_syll) > 0:
        X_syll = np.array(X_syll)
        plt.scatter(X_syll[:, 0], X_syll[:, 1],
                    c='red', marker='^', s=120, label='Syllabary')
        for i, (x, y) in enumerate(X_syll):
            plt.annotate(labels_syll[i], (x, y), fontsize=8, color='red')

    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()


def plot_ground_truth(title, X, labels, true_labels, label_map, syllabary_list):
    plt.figure(figsize=(9, 6))
    X = np.array(X)
    true_labels = np.array(true_labels)

    for i, (x, y) in enumerate(X):
        label = labels[i]
        color_idx = true_labels[i]
        color = plt.cm.tab10(color_idx)

        if label in syllabary_list:
            plt.scatter(x, y, marker='^', color=color, s=120, edgecolor='k')
            plt.annotate(label, (x, y), fontsize=8, color='red')
        else:
            plt.scatter(x, y, marker='o', color=color, s=100)
            plt.annotate(label, (x, y), fontsize=8)

    used_classes = sorted(set(true_labels))
    handles = []
    for val in used_classes:
        name = [k for k, v in label_map.items() if v == val][0]
        marker = '^' if name == 'syllabary' else 'o'
        handles.append(
            plt.Line2D([0], [0], marker=marker, color='w',
                       markerfacecolor=plt.cm.tab10(val),
                       label=name, markeredgecolor='k', markersize=10)
        )

    plt.legend(handles=handles, title="Ground Truth")
    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.grid(True)
    plt.tight_layout()
    plt.show()



def purity_score(y_true, y_pred):
    contingency_matrix = np.zeros((len(set(y_true)), len(set(y_pred))))
    for i, true_label in enumerate(set(y_true)):
        for j, pred_label in enumerate(set(y_pred)):
            contingency_matrix[i, j] = np.sum((np.array(y_true) == true_label) & (np.array(y_pred) == pred_label))
    return np.sum(np.max(contingency_matrix, axis=0)) / np.sum(contingency_matrix)


def evaluate_clustering(name, true_labels, predicted_labels):
    ari = adjusted_rand_score(true_labels, predicted_labels)
    nmi = normalized_mutual_info_score(true_labels, predicted_labels)
    purity = purity_score(true_labels, predicted_labels)

    print(f"\n{name} Evaluation:")
    print(f"ARI: {ari:.3f}, NMI: {nmi:.3f}, Purity: {purity:.3f}")


def main():
    # Extract
    zip_path = r"C:\Users\amite\Desktop\Languages.zip"
    extract_folder = "Languages"

    if os.path.exists(extract_folder):
        print(f"Removing old folder: {extract_folder}")
        shutil.rmtree(extract_folder)

    print("Extracting ZIP file...")
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(extract_folder)
    print(f"Extracted to: {extract_folder}")

    # Model and language definitions
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    weights = ResNet50_Weights.DEFAULT
    resnet = resnet50(weights=weights)
    resnet = torch.nn.Sequential(*list(resnet.children())[:-1])
    resnet = resnet.to(device).eval()
    transform = weights.transforms()
    print("Model loaded.")

    if os.path.exists("language_embeddings.npy"):
        print("Loading cached embeddings...")
        language_embeddings = np.load("language_embeddings.npy", allow_pickle=True).item()
        if not language_embeddings:
            print("Cached embeddings file is empty. Recomputing from scratch...")
            os.remove("language_embeddings.npy")
            return main()
    else:
        print("Extracting features from images...")
        base_path = "Languages/Languages"
        language_embeddings = {}

        for language in os.listdir(base_path):
            language_path = os.path.join(base_path, language)
            if not os.path.isdir(language_path):
                continue

            print(f"Processing {language}")
            letter_features = []
            all_image_densities = []

            for letter in os.listdir(language_path):
                letter_path = os.path.join(language_path, letter)
                if not os.path.isdir(letter_path):
                    continue

                image_features = []

                for image_file in os.listdir(letter_path):
                    image_path = os.path.join(letter_path, image_file)
                    try:
                        img = Image.open(image_path).convert('L')
                        image_array = np.asarray(img)
                        density = np.count_nonzero(image_array) / image_array.size
                        all_image_densities.append(density)

                        features = extract_features(image_path, resnet, transform, device)
                        image_features.append(features)
                    except Exception as e:
                        print(f"Error with image {image_path}: {e}")

                if image_features:
                    letter_embedding = np.mean(image_features, axis=0)
                    letter_features.append(letter_embedding)

            if letter_features:
                language_embedding = np.mean(letter_features, axis=0)
                num_letters = len(letter_features)
                avg_density = np.mean(all_image_densities) if all_image_densities else 0.0
                combined_embedding = np.concatenate([language_embedding, [num_letters, avg_density]])
                language_embeddings[language] = combined_embedding

        if not language_embeddings:
            print("No embeddings were extracted. Please check folder paths or permissions.")
            return

        np.save("language_embeddings.npy", language_embeddings)
        print("Saved language embeddings to language_embeddings.npy")

    # Clustering
    # Separate syllabaries
    syllabary_languages = [
        "Japanese_(hiragana)",
        "Japanese_(katakana)"
    ]

    cluster_labels = []
    X = []
    syllabary_labels = []
    X_syllabary = []

    for lang, vec in language_embeddings.items():
        if lang in syllabary_languages:
            syllabary_labels.append(lang)
            X_syllabary.append(vec)
        else:
            cluster_labels.append(lang)
            X.append(vec)

    X = np.array(X)
    X_syllabary = np.array(X_syllabary)

    pca_2d = PCA(n_components=2)
    tsne_2d = TSNE(n_components=2, perplexity=10, random_state=42)
    umap_2d = umap.UMAP(n_components=2, random_state=42)

    X_pca = pca_2d.fit_transform(X)
    X_tsne = tsne_2d.fit_transform(X)
    X_umap = umap_2d.fit_transform(X)

    X_pca_syll = pca_2d.transform(X_syllabary)
    X_umap_syll = umap_2d.transform(X_syllabary)

    kmeans = KMeans(n_clusters=3, random_state=42, n_init='auto').fit(X)
    agglo = AgglomerativeClustering(n_clusters=3).fit(X)

    # Plot
    plot_with_syllabaries("KMeans - PCA", X_pca, cluster_labels, X_pca_syll, syllabary_labels, kmeans.labels_)
    plot_with_syllabaries("Agglomerative - PCA", X_pca, cluster_labels, X_pca_syll, syllabary_labels, agglo.labels_)

    plot_with_syllabaries("KMeans - t-SNE", X_tsne, cluster_labels, [], [], kmeans.labels_)
    plot_with_syllabaries("Agglomerative - t-SNE", X_tsne, cluster_labels, [], [], agglo.labels_)

    plot_with_syllabaries("KMeans - UMAP", X_umap, cluster_labels, X_umap_syll, syllabary_labels, kmeans.labels_)
    plot_with_syllabaries("Agglomerative - UMAP", X_umap, cluster_labels, X_umap_syll, syllabary_labels, agglo.labels_)

    # Evaluate
    ground_truth = {
        "Alphabet_of_the_Magi": "alphabet",
        "Angelic": "alphabet",
        "Anglo-Saxon_Futhorc": "alphabet",
        "Arcadian": "alphabet",
        "Armenian": "alphabet",
        "Asomtavruli_(Georgian)": "alphabet",
        "Avesta": "alphabet",
        "Balinese": "abugida",
        "Bengali": "abugida",
        "Blackfoot_(Canadian_Aboriginal_Syllabics)": "abugida",
        "Burmese_(Myanmar)": "abugida",
        "Cyrillic": "alphabet",
        "Early_Aramaic": "abjad",
        "Ge_ez": "abugida",
        "Glagolitic": "alphabet",
        "Grantha": "abugida",
        "Greek": "alphabet",
        "Gujarati": "abugida",
        "Gurmukhi": "abugida",
        "Hebrew": "abjad",
        "Inuktitut_(Canadian_Aboriginal_Syllabics)": "abugida",
        "Japanese_(hiragana)": "syllabary",
        "Japanese_(katakana)": "syllabary",
        "Kannada": "abugida",
        "Korean": "alphabet",
        "Latin": "alphabet",
        "Malayalam": "abugida",
        "Manipuri": "abugida",
        "Mkhedruli_(Georgian)": "alphabet",
        "Mongolian": "alphabet",
        "N_Ko": "alphabet",
        "Ojibwe_(Canadian_Aboriginal_Syllabics)": "abugida",
        "Old_Church_Slavonic_(Cyrillic)": "alphabet",
        "Oriya": "abugida",
        "Sanskrit_(Nandinagari)": "abugida",
        "Sylheti": "abugida",
        "Syriac_(Estrangelo)": "abjad",
        "Syriac_(Serto)": "abjad",
        "Tagalog_(baybayin)": "abugida",
        "Tibetan": "abugida",
        "Tifinagh": "alphabet"
    }

    label_map = {'alphabet': 0, 'abugida': 1, 'abjad': 2, 'syllabary': 3}
    gt_labels = [label_map[ground_truth[lang]] for lang in cluster_labels]
    labels = list(language_embeddings.keys())
    gt_labels_full = [label_map[ground_truth[lang]] for lang in labels]
    plot_ground_truth("Ground Truth - UMAP", X_umap, labels, gt_labels_full, label_map, syllabary_languages)

    evaluate_clustering("KMeans", gt_labels, kmeans.labels_)
    evaluate_clustering("Agglomerative", gt_labels, agglo.labels_)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("Script crashed with error:")
        traceback.print_exc()
