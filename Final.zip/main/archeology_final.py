import os
import numpy as np
import torch
from PIL import Image
from torchvision.models import resnet50, ResNet50_Weights
import torchvision.transforms as transforms
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, homogeneity_completeness_v_measure
import umap
import zipfile
import traceback
import shutil

def extract_features(image_path, resnet, transform, device):
    image = Image.open(image_path).convert('RGB')
    image = transform(image).unsqueeze(0).to(device)
    with torch.no_grad():
        features = resnet(image)
    return features.squeeze().cpu().numpy()

def plot_by_ground_truth(title, X_main, labels_main, ground_truth):
    plt.figure(figsize=(9, 6))
    color_map = {'alphabet': 'green', 'abugida': 'purple', 'abjad': 'blue', 'syllabary': 'red', 'unknown': 'gray'}
    for i, lang in enumerate(labels_main):
        gt = ground_truth.get(lang, 'unknown')
        plt.scatter(X_main[i, 0], X_main[i, 1], c=color_map[gt], label=gt if gt not in plt.gca().get_legend_handles_labels()[1] else None, s=100)
        plt.annotate(lang, (X_main[i, 0], X_main[i, 1]), fontsize=8)
    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

def plot_with_syllabaries(title, X_main, labels_main, X_syll, labels_syll, clusters):
    plt.figure(figsize=(9, 6))
    plt.scatter(X_main[:, 0], X_main[:, 1], c=clusters, cmap='viridis', s=100, label='Clustered')

    for i, lang in enumerate(labels_main):
        plt.annotate(lang, (X_main[i, 0], X_main[i, 1]), fontsize=8)

    if len(X_syll) > 0:
        plt.scatter(X_syll[:, 0], X_syll[:, 1], c='red', marker='^', s=120, label='Syllabary')
        for i, lang in enumerate(labels_syll):
            plt.annotate(lang, (X_syll[i, 0], X_syll[i, 1]), fontsize=8, color='red')

    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()


def main():
    # Step 0: Extract
    zip_path = r"C:\Users\amite\Desktop\Languages.zip"
    extract_folder = "Languages"

    if os.path.exists(extract_folder):
        print(f"Removing old folder: {extract_folder}")
        shutil.rmtree(extract_folder)

    print("Extracting ZIP file...")
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(extract_folder)
    print(f"Extracted to: {extract_folder}")

    # Step 1: Load ResNet and define transform
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    weights = ResNet50_Weights.DEFAULT
    resnet = resnet50(weights=weights)
    resnet = torch.nn.Sequential(*list(resnet.children())[:-1])
    resnet = resnet.to(device).eval()
    transform = weights.transforms()
    print("Model loaded.")

    syllabary_languages = [
        "Japanese_(hiragana)",
        "Japanese_(katakana)",
        "Ojibwe_(Canadian_Aboriginal_Syllabics)",
        "Inuktitut_(Canadian_Aboriginal_Syllabics)"
    ]

    ground_truth = {
        "Alphabet_of_the_Magi": "alphabet",
        "Angelic": "alphabet",
        "Anglo-Saxon_Futhorc": "alphabet",
        "Arcadian": "alphabet",
        "Armenian": "alphabet",
        "Asomtavruli_(Georgian)": "alphabet",
        "Avesta": "alphabet",
        "Balinese": "abugida",
        "Bengali": "abugida",
        "Blackfoot_(Canadian_Aboriginal_Syllabics)": "abugida",
        "Burmese_(Myanmar)": "abugida",
        "Cyrillic": "alphabet",
        "Early_Aramaic": "abjad",
        "Ge_ez": "abugida",
        "Glagolitic": "alphabet",
        "Grantha": "abugida",
        "Greek": "alphabet",
        "Gujarati": "abugida",
        "Gurmukhi": "abugida",
        "Hebrew": "abjad",
        "Inuktitut_(Canadian_Aboriginal_Syllabics)": "syllabary",
        "Japanese_(hiragana)": "syllabary",
        "Japanese_(katakana)": "syllabary",
        "Kannada": "abugida",
        "Korean": "alphabet",
        "Latin": "alphabet",
        "Malayalam": "abugida",
        "Manipuri": "abugida",
        "Mkhedruli_(Georgian)": "alphabet",
        "Mongolian": "alphabet",
        "N_Ko": "alphabet",
        "Ojibwe_(Canadian_Aboriginal_Syllabics)": "syllabary",
        "Old_Church_Slavonic_(Cyrillic)": "alphabet",
        "Oriya": "abugida",
        "Sanskrit_(Nandinagari)": "abugida",
        "Sylheti": "abugida",
        "Syriac_(Estrangelo)": "abjad",
        "Syriac_(Serto)": "abjad",
        "Tagalog_(Baybayin)": "abugida",
        "Tibetan": "abugida",
        "Tifinagh": "alphabet"
    }

    # Step 2: Extract features
    if os.path.exists("language_embeddings.npy"):
        print("Loading cached embeddings...")
        language_embeddings = np.load("language_embeddings.npy", allow_pickle=True).item()
        if not language_embeddings:
            print("Cached embeddings file is empty. Recomputing from scratch...")
            os.remove("language_embeddings.npy")
            return main()
    else:
        print("Extracting features from images...")
        base_path = "Languages/Languages"
        language_embeddings = {}

        for language in os.listdir(base_path):
            language_path = os.path.join(base_path, language)
            if not os.path.isdir(language_path):
                continue

            print(f"Processing {language}")
            letter_features = []
            all_image_densities = []

            for letter in os.listdir(language_path):
                letter_path = os.path.join(language_path, letter)
                if not os.path.isdir(letter_path):
                    continue

                image_features = []

                for image_file in os.listdir(letter_path):
                    image_path = os.path.join(letter_path, image_file)
                    try:
                        img = Image.open(image_path).convert('L')
                        image_array = np.asarray(img)
                        density = np.count_nonzero(image_array) / image_array.size
                        all_image_densities.append(density)

                        features = extract_features(image_path, resnet, transform, device)
                        image_features.append(features)
                    except Exception as e:
                        print(f"Error with image {image_path}: {e}")

                if image_features:
                    letter_embedding = np.mean(image_features, axis=0)
                    letter_features.append(letter_embedding)

            if letter_features:
                language_embedding = np.mean(letter_features, axis=0)
                num_letters = len(letter_features)
                avg_density = np.mean(all_image_densities) if all_image_densities else 0.0
                combined_embedding = np.concatenate([language_embedding, [num_letters, avg_density]])
                language_embeddings[language] = combined_embedding

        if not language_embeddings:
            print("No embeddings were extracted. Please check folder paths or permissions.")
            return

        np.save("language_embeddings.npy", language_embeddings)
        print("Saved language embeddings to language_embeddings.npy")

    # Step 3: Clustering
    labels = list(language_embeddings.keys())
    X = np.array(list(language_embeddings.values()))

    # Separate syllabaries
    cluster_labels = []
    X_cluster = []
    syllabary_labels = []
    X_syllabary = []

    for lang, vec in zip(labels, X):
        if lang in syllabary_languages:
            syllabary_labels.append(lang)
            X_syllabary.append(vec)
        else:
            cluster_labels.append(lang)
            X_cluster.append(vec)

    X_cluster = np.array(X_cluster)
    X_syllabary = np.array(X_syllabary)

    pca_50 = PCA(n_components=min(50, X_cluster.shape[1], X_cluster.shape[0]))
    X_reduced = pca_50.fit_transform(X_cluster)
    X_syllabary_reduced = pca_50.transform(X_syllabary)

    pca_2d = PCA(n_components=2)
    tsne_2d = TSNE(n_components=2, perplexity=10, random_state=42)
    umap_2d = umap.UMAP(n_components=2, random_state=42)

    X_pca = pca_2d.fit_transform(X_reduced)
    X_tsne = tsne_2d.fit_transform(X_reduced)
    X_umap = umap_2d.fit_transform(X_reduced)

    X_pca_syll = pca_2d.transform(X_syllabary_reduced)
    X_umap_syll = umap_2d.transform(X_syllabary_reduced)

    kmeans = KMeans(n_clusters=3, random_state=42, n_init='auto').fit(X_reduced)
    agglo = AgglomerativeClustering(n_clusters=3).fit(X_reduced)

    # Step 4: Plot
    plot_with_syllabaries("KMeans - PCA", X_pca, cluster_labels, X_pca_syll, syllabary_labels, kmeans.labels_)
    plot_with_syllabaries("Agglomerative - PCA", X_pca, cluster_labels, X_pca_syll, syllabary_labels, agglo.labels_)

    plot_with_syllabaries("KMeans - t-SNE", X_tsne, cluster_labels, [], [], kmeans.labels_)
    plot_with_syllabaries("Agglomerative - t-SNE", X_tsne, cluster_labels, [], [], agglo.labels_)

    plot_with_syllabaries("KMeans - UMAP", X_umap, cluster_labels, X_umap_syll, syllabary_labels, kmeans.labels_)
    plot_with_syllabaries("Agglomerative - UMAP", X_umap, cluster_labels, X_umap_syll, syllabary_labels, agglo.labels_)

    #step 6: compare
    ground_truth_dict = {
        "abjad": ['Early_Aramaic', 'Hebrew', 'Syriac_(Estrangelo)', 'Syriac_(Serto)'],
        "abugida": ['Balinese', 'Bengali', 'Blackfoot_(Canadian_Aboriginal_Syllabics)', 'Burmese_(Myanmar)', 'Ge_ez',
                    'Grantha', 'Gujarati', 'Gurmukhi', 'Kannada', 'Malayalam', 'Manipuri', 'Oriya', 'Sanskrit (Nandinagari)',
                    'Sylheti', 'Tagalog (baybayin)', 'Tibetan'],
        "alphabet": ['Alphabet_of_the_Magi', 'Angelic', 'Anglo-Saxon_Futhorc', 'Arcadian', 'Armenian',
                     'Asomtavruli_(Georgian)', 'Avesta', 'Cyrillic', 'Glagolitic', 'Greek', 'Korean', 'Latin',
                     'Mkhedruli_(Georgian)', 'Mongolian', 'N_Ko', 'Old_Church_Slavonic_(Cyrillic)', 'Tifinagh'],
        "syllabary": ['Inuktitut_(Canadian_Aboriginal_Syllabics)', 'Japanese_(hiragana)', 'Japanese_(katakana)',
                      'Ojibwe_(Canadian_Aboriginal_Syllabics)']
    }

    gt_flat = {}
    for label, langs in ground_truth_dict.items():
        for lang in langs:
            gt_flat[lang] = label

    label_map = {'alphabet': 0, 'abugida': 1, 'abjad': 2, 'syllabary': 3}
    gt_labels = [label_map[gt_flat[lang]] for lang in cluster_labels]  # only non-syllabaries

    kmeans_labels = kmeans.labels_
    ari_k, nmi_k = adjusted_rand_score(gt_labels, kmeans_labels), normalized_mutual_info_score(gt_labels, kmeans_labels)
    hom_k, comp_k, v_k = homogeneity_completeness_v_measure(gt_labels, kmeans_labels)
    print("\nKMeans Evaluation:")
    print(
        f"ARI: {ari_k:.3f}, NMI: {nmi_k:.3f}, Homogeneity: {hom_k:.3f}, Completeness: {comp_k:.3f}, V-Measure: {v_k:.3f}")

    agglo_labels = agglo.labels_
    ari_a, nmi_a = adjusted_rand_score(gt_labels, agglo_labels), normalized_mutual_info_score(gt_labels, agglo_labels)
    hom_a, comp_a, v_a = homogeneity_completeness_v_measure(gt_labels, agglo_labels)
    print("\nAgglomerative Evaluation:")
    print(
        f"ARI: {ari_a:.3f}, NMI: {nmi_a:.3f}, Homogeneity: {hom_a:.3f}, Completeness: {comp_a:.3f}, V-Measure: {v_a:.3f}")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("Script crashed with error:")
        traceback.print_exc()
